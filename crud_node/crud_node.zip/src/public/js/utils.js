export function clearFormFields(formId) {
    const form = document.getElementById(formId);
    form.reset();
}

export const appName = "Mi Aplicación de Ejemplo";