export const {

    PORT = 3000



} = process.env