export function saludar(nombre) {
    console.log(`¡Hola, ${nombre}!`);
}

export function sumar(a, b) {
    return a + b;
}

export function restar(a, b) {
    return a - b;
}